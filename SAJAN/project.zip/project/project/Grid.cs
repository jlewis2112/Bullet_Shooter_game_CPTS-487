﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace project
{
    public class Grid
    {
        public Vector2 GetCoordinates(Vector2 position)
        {
            return GetCoordinates(position.X, position.Y);
        }

        public Vector2 GetCoordinates(float x, float y)
        {
            Vector2 vec = new Vector2();
            return vec;
        }
    }
}
