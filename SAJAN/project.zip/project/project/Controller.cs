﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace project
{
    class Controller :Object
    {

        private List<Object> entityVector;
        private GameTime gameTime;
        private Player myPlayer;
        public Controller() 
        {
            //this.gameTime = time;
            this.entityVector = new List<Object>();
            myPlayer = new Player();
        }

        public void addPlayerObject(Player newPlayer) {
            myPlayer = newPlayer;
        }
        public void addObject(Object newObject)
        {
            entityVector.Add(newObject);
        }

        public void Update(GameTime time) // Add manager class to handle controller
        {
            this.gameTime = time;
            foreach (Object obj in entityVector)
            {
                obj.update(gameTime);
            }           
        }

        public void updatePlayer(GameTime gameTime)
        {
            myPlayer.update(gameTime);
        }
    }
}
